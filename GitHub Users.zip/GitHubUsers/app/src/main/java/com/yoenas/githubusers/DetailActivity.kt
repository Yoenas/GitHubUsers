package com.yoenas.githubusers

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.yoenas.githubusers.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DATA_USER = "user"
    }

    private lateinit var binding: ActivityDetailBinding
    private var dataUser: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Detail GitHub User"
        }

        dataUser = intent.getParcelableExtra(EXTRA_DATA_USER)

        initView()
    }

    private fun initView() {
        val imageResource: Int = resources.getIdentifier(dataUser?.avatar, null, packageName)
        val image: Drawable? = ResourcesCompat.getDrawable(resources, imageResource, null)
        binding.imgAvatarDetail.setImageDrawable(image)

        binding.tvNameDetail.text = dataUser?.name
        binding.tvUsernameDetail.text = dataUser?.username
        binding.tvCompanyDetail.text = dataUser?.company
        binding.tvLocationDetail.text = dataUser?.location
        binding.tvRepositaryDetail.text = dataUser?.repository.toString()
        binding.tvFollowersDetail.text = dataUser?.follower.toString()
        binding.tvFollowingDetail.text = dataUser?.following.toString()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_menu_share -> {

                val textValue = "This is ${dataUser?.name}'s GitHub User Profile\n" +
                        "Username: ${dataUser?.username}\n" +
                        "Company: ${dataUser?.company}\n" +
                        "Location: ${dataUser?.location}\n" +
                        "Total ${dataUser?.repository} Repositories\n" +
                        "${dataUser?.follower} Followers & ${dataUser?.following} Following"

                val sendIntent: Intent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, textValue)
                    type = "text/plain"
                }

                val shareIntent = Intent.createChooser(sendIntent, getString(R.string.txt_share_to))
                startActivity(shareIntent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}